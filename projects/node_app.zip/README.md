# Setup

Install packages
```
npm install
```

# Run

Run server
```
node index.js
```

Test application
```
curl http://localhost:3000
```
> Should return : **Hello, World!**